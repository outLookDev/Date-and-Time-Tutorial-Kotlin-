package tv

interface TvInterface {
    fun addTvShow()
    fun searchTvShow()
    fun watchShow()
    fun editShow()
    fun removeShow()
    fun showList()

}