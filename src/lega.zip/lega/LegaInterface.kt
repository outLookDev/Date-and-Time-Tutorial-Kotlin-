package lega

interface LegaInterface {
    fun addCollision()
    fun searchCollision()
    fun collisionList()
    fun todayCollision()
}