package ligaDate

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Scanner
import kotlin.random.Random

class FootballService : FootballInterface {
    var footballLegaList = ArrayList<Football>()
    var scanner = Scanner(System.`in`)

    override fun addFootballLega() {
        println("Lega name :")
        var lega=scanner.next()
        println("One Football team name :")
        var teamOne = scanner.next()
        println("Two Football team name :")
        var teamTwo = scanner.next()
        println("Collision Month : examp : March 3 :")
        var monthCollision = scanner.nextInt()
        println("Collision day /Oyga nisbatan  :")
        var dayCollision = scanner.nextInt()
        println("Collision hour :")
        var collisionHour = scanner.nextInt()
        println(" Collision minute :")
        var collisionMinute = scanner.nextInt()
        println("end Collision hour :")
        var endcollisionHour = scanner.nextInt()
        println("end Collision minute :")
        var endcollisionMinute = scanner.nextInt()
         if (collisionHour>=endcollisionHour){
            println("Invalid hour !")
        }
        else{
        var football = Football()
             football.legaName=lega
        football.collisionTime = LocalDateTime.of(2022, monthCollision, dayCollision, collisionHour, collisionMinute)
        football.endCollisionTime =
            LocalDateTime.of(2022, monthCollision,dayCollision , endcollisionHour, endcollisionMinute)
        var random = Random(10)
        football.levelTeamOne = random.nextInt(1, 10)
        football.levelTeamTwo = random.nextInt(from = 1, until = 10)
        football.footballTeamOneName = teamOne
        football.footballTeamTwoName = teamTwo
        footballLegaList.add(football)
        println("Success !")}

    }

    override fun removeFootballLega() {
        if (footballLegaList.isEmpty()) {
            println("List bo`sh !")
        } else {
            println("remove Lega name :")
            var searchName = scanner.next()
            var index = -1
            for (i in 0 until footballLegaList.size) {
                if (searchName == footballLegaList[i].legaName) {
                    index = i
                    break
                }
            }
            if (index != -1) {
                footballLegaList.removeAt(index)
                println("Success !")
            } else {
                println("Bunday lega yuq")
            }
        }
    }

    override fun footballLegaList() {
        if (footballLegaList.isEmpty()) {
            println("List bo`sh !")
        } else {
            for (i in 0 until footballLegaList.size) {
                println("======================${i + 1}=================")
                println("Lega name : ${footballLegaList[i].legaName}")
                println("Lega team one : ${footballLegaList[i].footballTeamOneName}")
                println("team two : ${footballLegaList[i].footballTeamTwoName}")
                var startTimeFormat =
                    footballLegaList[i].collisionTime?.format(DateTimeFormatter.ofPattern("MMM/dd HH:mm"))
                var endFormat =
                    footballLegaList[i].endCollisionTime?.format(DateTimeFormatter.ofPattern("MMM/dd HH:mm"))
                println("collision time : $startTimeFormat")
                println("collision end time : $endFormat")
                println("=======================================================")

            }


        }
    }

    override fun editLega() {
        if (footballLegaList.isEmpty()) {
            println("List bo`sh !")
        } else {
            println("edit Lega name :")
            var searchName = scanner.next()
            var index = -1
            for (i in 0 until footballLegaList.size) {
                if (searchName == footballLegaList[i].legaName) {
                    index = i
                    break
                }
            }
            if (index != -1) {
                println("new Lega name :")
                var newLega = scanner.next()
                println("Team one name :")
                var teamOne = scanner.next()
                println("Team two  name:")
                var teamTwo = scanner.next()
                footballLegaList[index].legaName = newLega
                footballLegaList[index].footballTeamTwoName = teamTwo
                footballLegaList[index].footballTeamOneName = teamOne
                println("Success !")


            } else {
                println("Bunday lega yuq")
            }
        }
    }

    override fun searchLega() {
        if (footballLegaList.isEmpty()) {
            println("List bo`sh !")
        } else {
            println("search Lega name :")
            var searchName = scanner.next()
            var index = -1
            for (i in 0 until footballLegaList.size) {
                if (searchName == footballLegaList[i].legaName) {
                    index = i
                    break
                }
            }
            if (index != -1) {
                println("======================${index + 1}=================")
                println("Lega name : ${footballLegaList[index].legaName}")
                println("Lega team one : ${footballLegaList[index].footballTeamOneName}")
                println("team two : ${footballLegaList[index].footballTeamTwoName}")
                var startTimeFormat =
                    footballLegaList[index].collisionTime?.format(DateTimeFormatter.ofPattern("MMM/dd HH:mm"))
                var endFormat =
                    footballLegaList[index].endCollisionTime?.format(DateTimeFormatter.ofPattern("MMM/dd HH:mm"))
                println("collision time : $startTimeFormat")
                println("collision end time : $endFormat")
                println("=======================================================")
            } else {
                println("Bunday lega yuq")
            }
        }
    }

    override fun legaWatch() {
        if (footballLegaList.isEmpty()) {
            println("Show list is Empty !")
        } else {
            println("Vaqtni kiriting soatda :")
            var hour = scanner.nextInt()
            println("Vaqtni kiriting minute :")
            var minute = scanner.nextInt()
            var isHave = false
            var index = -1
            for (i in 0 until footballLegaList.size) {
                if (((footballLegaList[i].collisionTime?.hour!! < hour || footballLegaList[i].collisionTime?.hour == hour) &&
                            (footballLegaList[i].collisionTime?.minute == minute || footballLegaList[i].collisionTime?.minute!! < minute)) || (((footballLegaList[i].endCollisionTime?.hour!! > hour) || (footballLegaList[i].endCollisionTime?.hour == hour)) && (footballLegaList[i].endCollisionTime?.minute!! > minute || footballLegaList[i].endCollisionTime?.minute == minute))
                ) {
                    isHave = true
                    index = i
                    break
                }
            }
            if (isHave) {
                var startTimeFormat =
                    footballLegaList[index].collisionTime?.format(DateTimeFormatter.ofPattern("MMM/dd HH:mm"))
                var endFormat =
                    footballLegaList[index].endCollisionTime?.format(DateTimeFormatter.ofPattern("MMM/dd HH:mm"))
                println("Lega name : ${footballLegaList[index].legaName}")
                println("Team one name: ${footballLegaList[index].footballTeamOneName}")
                println("Team two name : ${footballLegaList[index].footballTeamTwoName}")
                println("Levels team one :${footballLegaList[index].levelTeamOne}")
                println("Levels team two :${footballLegaList[index].levelTeamTwo}")
                println("Natija ${footballLegaList[index].levelTeamOne} : ${footballLegaList[index].levelTeamTwo}")
                println("Boshlanish vaqti $startTimeFormat")
                println("tugash vaqti $endFormat")
                println("Maroqli hordiq tilaymaiz ! ")
                println("========================================")
            } else {
                println("Show is Not Found !")
            }
        }
    }
}