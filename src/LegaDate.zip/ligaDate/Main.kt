package ligaDate

import java.util.Scanner

fun main(args: Array<String>) {
    var footballService=FootballService()
    var scanner=Scanner(System.`in`)
    while (true){
        println("1-> Lega qo`shish !")
        println("2-> Search Lega !")
        println("3-> Remove Lega !")
        println("4-> Lega List !")
        println("5-> Watch lega playing !")
        println("6-> Edit Lega !")
        println("Choose :")
        var c=scanner.nextInt()
        when(c){
            1->{
                footballService.addFootballLega()
            }
            2->{
                footballService.searchLega()
            }
            3->{
                footballService.removeFootballLega()
            }
            4->{
                footballService.footballLegaList()
            }
            5->{
                footballService.legaWatch()
            }
            6->{
                footballService.editLega()
            }
            else -> println("Invalid choose number !")
        }
    }
}