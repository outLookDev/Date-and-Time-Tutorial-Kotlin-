package ligaDate

import java.time.LocalDateTime
import javax.naming.Name

class Football {
    var legaName=""
    var footballTeamOneName=""
    var footballTeamTwoName=""
    var collisionTime:LocalDateTime?=null
    var endCollisionTime:LocalDateTime?=null
    var levelTeamOne=0
    var levelTeamTwo=0
    constructor()
    constructor(
        legaName: String,
        footballTeamOneName: String,
        footballTeamTwoName: String,
        collisionTime: LocalDateTime?,
        endCollisionTime: LocalDateTime?,
        levelTeamOne: Int,
        levelTeamTwo: Int
    ) {
        this.legaName = legaName
        this.footballTeamOneName = footballTeamOneName
        this.footballTeamTwoName = footballTeamTwoName
        this.collisionTime = collisionTime
        this.endCollisionTime = endCollisionTime
        this.levelTeamOne = levelTeamOne
        this.levelTeamTwo = levelTeamTwo
    }


}