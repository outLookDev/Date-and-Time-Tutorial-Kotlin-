package ligaDate

interface FootballInterface {
    fun addFootballLega()
    fun removeFootballLega()
    fun footballLegaList()
    fun editLega()
    fun searchLega()
    fun legaWatch()


}